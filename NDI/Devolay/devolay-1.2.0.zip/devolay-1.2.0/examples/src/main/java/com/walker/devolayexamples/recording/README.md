#This example is *very* work in progress.
You can use this example to some extent for reference, but it is highly unfinished and not properly documented.